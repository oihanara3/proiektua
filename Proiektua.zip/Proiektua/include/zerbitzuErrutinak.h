// 2023-2024 ikasturtea

/*-------------------------------------
zerbitzuErrutinak.h
-------------------------------------*/

extern void tekEten ();
extern void tenpEten();
extern void etenZerbErrutEzarri();
