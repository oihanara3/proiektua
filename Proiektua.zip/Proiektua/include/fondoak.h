// 2023-2024 ikasturtea

/*-------------------------------------
fondoak.h
-------------------------------------*/

extern void erakutsiFondoBat();
extern void erakutsiFondoBi();
