// 2023-2024 ikasturtea

/*-------------------------------------
fondoak.h
-------------------------------------*/

extern void erakutsiFondo();
extern void erakutsiArkanoid();
extern void erakutsiFondoBat();
extern void erakutsiFondoBi();
extern void erakutsiAtea();
extern void erakutsiAteaIrekita();
