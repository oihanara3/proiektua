

extern void setLevelOne();
extern void paintLevel();

extern int kajak[3][8];

extern void kutxaKendu(int indizea,int x,int y);
