
extern void reset();
extern void setLevel(int levelCount);
extern int paintLevel(int kajaKop);
extern void paintReset();

extern int kajak[3][8];

extern void kutxaKendu(int indizea,int x,int y);
