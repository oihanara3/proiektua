extern int updateNory(int py, int yNorabide, int px, int PalaX);
extern int updatePosy();
extern int updateNorx(int py, int xNorabide, int px, int PalaX);
extern int updatePosx();
extern void pelotaMugitu();

extern int ukituKutxaBehetik(int py, int px);
extern int ukituKutxaGoitik(int py, int px);
extern int ukituKutxaAldetatik(int py, int px);
