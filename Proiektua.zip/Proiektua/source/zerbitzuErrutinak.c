/*-------------------------------------
periferikoak.c
-------------------------------------*/

#include <nds.h>
#include <stdio.h>
#include "definizioak.h"
#include "periferikoak.h"
#include "fondoak.h"
#include "spriteak.h"
#include "pelotamug.h"
#include "kajak.h"

int EGOERA;
//pala
int PalaX;
int kontPala = 0;

//pelota
int yNorabide;
int xNorabide;
int py=155;
int px = 120;
int tik = 0;
int tenpPel = 0;

//kajak
int kajaKop = 1;

//bizitzak
int lives = 3;

//puntuak
int points=0;
int highscore=0;

//nibelak
int levelCount=1;


//pantaila
touchPosition pos_pantaila; // aldagaiaren definizioa


void tekEten ()
{

if (EGOERA == GELDIK)
{	
	if (SakatutakoTekla()==A)
	{
		if(lives == 0)
		{
			if(points > highscore)
			{
				highscore = points;
			}
			points = 0;
			levelCount=1;
			reset();
			paintReset();
			lives = 3;
		}else if(kajaKop == 0)
		{
			reset();
			levelCount++;
			if(levelCount == 4)
			{
				levelCount = 1;
			}
		}
		yNorabide = -1;
		xNorabide = 1;
		py=139;
		px = 112;
		PalaX=100;
		setLevel(levelCount);
		kajaKop = paintLevel(kajaKop);
		EGOERA=MUGIMENDUAN;
		erakutsiFondo();
		
	}else if(SakatutakoTekla()==B){
		EzabatuPala(26, PalaX, 170);
		kutxaGuztiakKendu();
		EzabatuPelota(25,px,py);
		EGOERA=AMAIERA;
	}
}else if(EGOERA == MUGIMENDUAN)
{
	if (SakatutakoTekla()== ESKUBI)
	{
		kontPala++;
		if(kontPala == 50 && PalaX !=224)
		{
			PalaX += 1;
			kontPala=0;
		}else if (PalaX == 224)
		{
			kontPala=0;
		}
	}else if(SakatutakoTekla()== EZKER)
	{
		kontPala++;
		if(kontPala == 50 && PalaX !=0)
		{
			PalaX -= 1;
			kontPala=0;
		}else if (PalaX == 0)
		{
			kontPala=0;
		}
	}

	tenpPel++;
	if(tenpPel == 60)
	{
		pelotaMugitu();
		tenpPel = 0;
	}
	ErakutsiPala(26, PalaX, 170);
}
}

void tenpEten()
{	

if (EGOERA == MUGIMENDUAN)
{
	tik++;
	if(tik == 10000)
	{
		pelotaMugitu();
		tik=0;
	}
	
	if(py == 176)
	{
		lives--;
		EGOERA = GELDIK;
		if(lives==0)
		{
			erakutsiArkanoid();
			reset();
			paintReset();
		}
	}

	if(kajaKop == 0){
		EGOERA = GELDIK;
	}
	
	
}
	
}

void panEten()
{

	touchRead(&pos_pantaila); // posizioaren irakurketa

	while(pos_pantaila.px==0 && pos_pantaila.py==0)
	{
		touchRead(&pos_pantaila);
	}

	iprintf("\x1b[17;5HPaintaila ukitu da=%d",pos_pantaila.px);
	
	if(EGOERA == MUGIMENDUAN)
	{
		if (pos_pantaila.px > 128)
		{
			kontPala++;
			if(kontPala == 50 && PalaX !=224)
			{
				PalaX += 1;
				kontPala=0;
			}else if (PalaX == 224)
			{
				kontPala=0;
			}
		}else if(pos_pantaila.px <= 128)
		{
			kontPala++;
			if(kontPala == 50 && PalaX !=0)
			{
				PalaX -= 1;
				kontPala=0;
			}else if (PalaX == 0)
			{
				kontPala=0;
			}
		}
		tenpPel++;
		if(tenpPel == 60)
		{
			pelotaMugitu();
			tenpPel = 0;
		}
		ErakutsiPala(26, PalaX, 170);
	}
	
}



void etenZerbErrutEzarri()
{
	// HAU BETE
	irqSet(IRQ_KEYS, tekEten);
	irqSet(IRQ_TIMER0, tenpEten);
	irqSet(IRQ_VCOUNT, panEten);
}
