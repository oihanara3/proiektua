/*-------------------------------------
periferikoak.c
-------------------------------------*/

#include <nds.h>
#include <stdio.h>
#include "definizioak.h"
#include "periferikoak.h"
#include "fondoak.h"
#include "spriteak.h"
#include "pelotamug.h"
#include "kajak.h"

int EGOERA;
//pala
int PalaX;
int kontPala = 0;


//pelota
int yNorabide;
int xNorabide;
int py=155;
int px = 120;
int tik = 0;



void tekEten ()
{
if (EGOERA == GELDIK)
{	
	if (SakatutakoTekla()==A)
	{
		yNorabide = -1;
		xNorabide = 1;
		py=139;
		px = 112;
		PalaX=100;
		setLevelOne();
		paintLevel();
		EGOERA=MUGIMENDUAN;
	}else if(SakatutakoTekla()==B){
		EGOERA=AMAIERA;
	}
}else if(EGOERA == MUGIMENDUAN)
{
	if (SakatutakoTekla()== ESKUBI)
	{
		kontPala++;
		if(kontPala == 50 && PalaX !=224)
		{
			PalaX += 1;
			kontPala=0;
			pelotaMugitu();
		}else if (PalaX == 224)
		{
			kontPala=0;
		}
	}else if(SakatutakoTekla()== EZKER)
	{
		kontPala++;
		if(kontPala == 50 && PalaX !=0)
		{
			PalaX -= 1;
			kontPala=0;
			pelotaMugitu();
		}else if (PalaX == 0)
		{
			kontPala=0;
		}
	}
	ErakutsiPala(26, PalaX, 170);
} 
}

void tenpEten()
{	

if (EGOERA == MUGIMENDUAN)
{
	tik++;
	if(tik == 10000)
	{
		pelotaMugitu();
		tik=0;
	}
	
	if(py == 176)
	{
		EGOERA = GELDIK;
	}	
	
}
	
}



void etenZerbErrutEzarri()
{
	// HAU BETE
	irqSet(IRQ_KEYS, tekEten);
	irqSet(IRQ_TIMER0, tenpEten);
}
