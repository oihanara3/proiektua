
#include "definizioak.h"

//UKITU DETEKTATZAILEAK
int palaUkitu(int py, int px, int PalaX)
{
	int val = 0;
	if(py-16==140 && PalaX <=px+14 && PalaX+32 >= px+2){
		val = 1;
	}
	iprintf("\x1b[13;5HPala ukitu=%d",val);
	iprintf("\x1b[15;5HPalaX=%d",PalaX);
	iprintf("\x1b[16;5HxNorabide=%d",xNorabide);
	iprintf("\x1b[17;5HPY=%d",py);
	iprintf("\x1b[18;5HPX=%d",px);
	return val;
}

//Y ARDATZA
int updatePosy()
{
	return py + yNorabide;
}

int updateNory(int py, int yNorabide, int px, int PalaX)
{
	if (py==0)
	{
		yNorabide = 1;
	}else if(py==176)
	{
		yNorabide =0;
	}else if(palaUkitu(py, px, PalaX) == 1)
	{
		
		yNorabide = -1;
	}

     	return yNorabide;
}

//X ARDATZA
int updatePosx()
{
	return px+xNorabide;
}

int updateNorx(int py, int xNorabide, int px, int PalaX)
{
	if(px<= 0 || px+16>=256)
	{
		xNorabide *= -1;
	}else if(py==176)
	{
		xNorabide = 0;
	}
	return xNorabide;
}

//PELOTAREN MUGIMENDUA EGUNERATZEN JOATEN DEN FUNTZIOA
void pelotaMugitu(){
	yNorabide = updateNory(py,yNorabide,px,PalaX);
	xNorabide = updateNorx(py,xNorabide,px,PalaX);
	py = updatePosy();
	px = updatePosx();
	ErakutsiPelota(2,px,py);
}


