
#include "definizioak.h"
#include "kajak.h"

//UKITU DETEKTATZAILEAK
int palaUkitu(int py, int px, int PalaX)
{
	int val = 0;
	if(py-16==150 && PalaX <=px+14 && PalaX+32 >= px+2){
		val = 1;
	}
	iprintf("\x1b[13;5HPala ukitu=%d",val);
	iprintf("\x1b[15;5HPalaX=%d",PalaX);
	iprintf("\x1b[16;5HxNorabide=%d",xNorabide);
	iprintf("\x1b[17;5HPY=%d",py);
	iprintf("\x1b[18;5HPX=%d",px);
	return val;
}

int ukituKutxaBehetik(int py, int px)
{
	int i;
	int j;
	int val = 0;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(kajak[i][j]!=-1 && j*32 <=px+14 && j*32+32 >= px+2 && i*32+20 == py )
			{
				val = kajak[i][j];
				kutxaKendu(val,j,i);
				kajak[i][j]=-1;
			}
	return val;
}

int ukituKutxaGoitik(int py, int px)
{
	int i;
	int j;
	int val = 0;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(kajak[i][j]!=-1 && j*32 <=px+14 && j*32+32 >= px+2 && i*32+12 == py+16 )
			{
				val = kajak[i][j];
				kutxaKendu(val,j,i);
				kajak[i][j]=-1;
			}
	return val;
}

int ukituKutxaAldetatik(int py, int px)
{
	int i;
	int j;
	int val = 0;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(kajak[i][j]!=-1 && (j*32+32 == px || j*32 == px+16) && i*32+12 <= py+15 &&  i*32+20 >= py+1)
			{
				val = kajak[i][j];
				kutxaKendu(val,j,i);
				kajak[i][j]=-1;
			}
	return val;
}

//Y ARDATZA
int updatePosy()
{
	return py + yNorabide;
}

int updateNory(int py, int yNorabide, int px, int PalaX)
{
	if (py==0 || ukituKutxaBehetik(py,px) != 0)
	{
		yNorabide = 1;
	}else if(py==176)
	{
		yNorabide =0;
	}else if(palaUkitu(py, px, PalaX) == 1 || ukituKutxaGoitik(py,px) != 0)
	{
		
		yNorabide = -1;
	}

     	return yNorabide;
}

//X ARDATZA
int updatePosx()
{
	return px+xNorabide;
}

int updateNorx(int py, int xNorabide, int px, int PalaX)
{
	if(px<= 0 || px+16>=256 || ukituKutxaAldetatik(py,px))
	{
		xNorabide *= -1;
	}else if(py==176)
	{
		xNorabide = 0;
	}
	return xNorabide;
}

//PELOTAREN MUGIMENDUA EGUNERATZEN JOATEN DEN FUNTZIOA
void pelotaMugitu(){
	yNorabide = updateNory(py,yNorabide,px,PalaX);
	xNorabide = updateNorx(py,xNorabide,px,PalaX);
	py = updatePosy();
	px = updatePosx();
	ErakutsiPelota(25,px,py);
}


