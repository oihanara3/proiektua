/*---------------------------------------------------------------------------------
Kode hau garatu da dovotoren "Simple sprite demo" adibidean eta Jaeden Ameronen beste
adibide batean oinarrituta.
---------------------------------------------------------------------------------*/

#include <nds.h> 		// NDS-rako garatuta dagoen liburutegia
#include <stdio.h>		// C-ko liburutegi estandarra sarrera eta irteerako funtzioak definitzen dituena
#include <stdlib.h>		// C-ko liburutegi estandarra memoria erreserbak eta zenbaki bihurketak egiteko
#include <unistd.h>		// Sistema eragileen arteko bateragarritasuna ziurtatzeko liburutegia
#include "spriteak.h"
#include "definizioak.h"

u16* gfxerronboHandia;
u16* gfxpala;
u16* gfxpelota;


/* Pantailan erakutsi nahi den sprite bakoitzeko memoria erreserbatu.*/
void memoriaErreserbatu()
{
	/* Pantaila nagusian gehitu nahi den sprite bakoitzarentzako horrelako bat egin behar da. */
	gfxerronboHandia=oamAllocateGfx(&oamMain, SpriteSize_32x32, SpriteColorFormat_256Color);
	gfxpala=oamAllocateGfx(&oamMain, SpriteSize_32x32, SpriteColorFormat_256Color);
	gfxpelota= oamAllocateGfx(&oamMain, SpriteSize_16x16, SpriteColorFormat_256Color);
}

/* Pixel bakoitzak har ditzakeen 256 balioetako bakoitzari kolore bat esleitu PANTAILA NAGUSIAN. 0 balioa gardena da 
   eta definitu gabeko balioak beltzak. SPRITEARI KOLOREAK ESLEITZEKO ALDATU*/
void PaletaNagusiaEzarri() {

	SPRITE_PALETTE[0] = RGB15(0,0,0);
	SPRITE_PALETTE[1] = RGB15(2,27,3);
	SPRITE_PALETTE[2] = RGB15(1,27,3);
	SPRITE_PALETTE[3] = RGB15(2,27,3);
	SPRITE_PALETTE[4] = RGB15(2,27,3);
	SPRITE_PALETTE[5] = RGB15(1,27,3);
	SPRITE_PALETTE[6] = RGB15(1,27,3);
	SPRITE_PALETTE[7] = RGB15(1,27,3);
	SPRITE_PALETTE[8] = RGB15(1,27,3);
	SPRITE_PALETTE[9] = RGB15(2,27,3);
	SPRITE_PALETTE[10] = RGB15(2,27,3);
	SPRITE_PALETTE[11] = RGB15(1,27,3);
	SPRITE_PALETTE[12] = RGB15(1,27,3);
	SPRITE_PALETTE[13] = RGB15(1,27,3);
	SPRITE_PALETTE[14] = RGB15(1,27,3);
	SPRITE_PALETTE[15] = RGB15(1,27,3);
	SPRITE_PALETTE[16] = RGB15(2,27,3);
	SPRITE_PALETTE[17] = RGB15(1,27,3);
	SPRITE_PALETTE[18] = RGB15(1,27,3);
	SPRITE_PALETTE[19] = RGB15(1,27,3);
	SPRITE_PALETTE[20] = RGB15(1,27,3);
	SPRITE_PALETTE[21] = RGB15(1,27,3);
	SPRITE_PALETTE[22] = RGB15(1,27,3);
	SPRITE_PALETTE[23] = RGB15(1,27,3);
	SPRITE_PALETTE[24] = RGB15(1,27,3);
	SPRITE_PALETTE[25] = RGB15(1,27,3);
	SPRITE_PALETTE[26] = RGB15(2,27,3);
	SPRITE_PALETTE[27] = RGB15(2,28,3);
	SPRITE_PALETTE[28] = RGB15(1,27,3);
	SPRITE_PALETTE[29] = RGB15(2,27,3);
	SPRITE_PALETTE[30] = RGB15(2,28,3);
	SPRITE_PALETTE[31] = RGB15(1,27,3);
	SPRITE_PALETTE[32] = RGB15(2,27,3);
	SPRITE_PALETTE[33] = RGB15(2,28,3);
	SPRITE_PALETTE[34] = RGB15(1,27,3);
	SPRITE_PALETTE[35] = RGB15(1,27,3);
	SPRITE_PALETTE[36] = RGB15(2,27,3);
	SPRITE_PALETTE[37] = RGB15(1,27,3);
	SPRITE_PALETTE[38] = RGB15(1,27,3);
	SPRITE_PALETTE[39] = RGB15(1,27,3);
	SPRITE_PALETTE[40] = RGB15(1,27,3);
	SPRITE_PALETTE[41] = RGB15(1,27,3);
	SPRITE_PALETTE[42] = RGB15(1,27,3);
	SPRITE_PALETTE[43] = RGB15(2,27,3);
	SPRITE_PALETTE[44] = RGB15(1,27,3);
	SPRITE_PALETTE[45] = RGB15(1,27,3);
	SPRITE_PALETTE[46] = RGB15(1,27,3);
	SPRITE_PALETTE[47] = RGB15(1,27,3);
	SPRITE_PALETTE[48] = RGB15(2,27,3);
	SPRITE_PALETTE[49] = RGB15(2,27,3);
	SPRITE_PALETTE[50] = RGB15(1,27,3);
	SPRITE_PALETTE[51] = RGB15(1,27,3);
	SPRITE_PALETTE[52] = RGB15(2,27,3);
	SPRITE_PALETTE[53] = RGB15(2,27,3);
	SPRITE_PALETTE[54] = RGB15(1,27,3);
	SPRITE_PALETTE[55] = RGB15(1,27,3);
	SPRITE_PALETTE[56] = RGB15(2,27,4);
	SPRITE_PALETTE[57] = RGB15(1,27,3);
	SPRITE_PALETTE[58] = RGB15(2,27,3);
	SPRITE_PALETTE[59] = RGB15(31,0,0);
}

/* 16x16 pixeleko Sprite baten definizioa erronbo bat marrazteko */
/* Memoriako bankuek duten lan egiteko modua dela eta, lehenengo lau lerroak goiko
   ezkerreko koadrantean erakusten dira, hurrengo lauak goiko eskuineko kuadrantean,
   hurrengo lauak beheko ezkerreko koadrantean eta azkeneko lauak beheko eskuineko koadrantean. 
   Alboko irudian ikusten den bezala. */

u8 pala[1024]=
{
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,2,2,2,2,2,2,1,1,2,2,2,2,2,2,3,4,5,6,7,8,8,8,9,10,11,12,13,14,14,15,16,17,18,19,
	20,20,20,20,13,21,22,20,20,20,20,20,23,24,25,20,20,20,20,20,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,8,8,8,8,8,8,8,
	8,15,15,15,15,15,15,15,15,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,0,0,0,0,0,0,0,0,2,2,2,2,
	2,2,2,2,2,2,2,2,2,2,2,2,8,8,8,8,8,8,8,8,15,15,15,15,15,15,15,15,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,
	20,20,20,20,0,0,0,0,0,0,0,0,2,2,2,2,2,2,26,27,2,2,2,2,2,2,26,27,8,8,8,7,6,28,29,30,15,14,14,13,12,31,32,33,20,20,20,20,34,
	21,35,36,20,20,20,20,20,22,37,38,20,20,20,20,20,25,39,40,23,24,25,20,20,20,20,20,41,42,22,20,20,20,20,20,43,44,21,34,20,20,
	20,20,33,32,31,12,13,14,14,15,30,29,28,6,7,8,8,8,27,26,2,2,2,2,2,2,27,26,2,2,2,2,2,2,0,0,0,0,0,0,0,0,20,20,20,20,20,20,20,20,
	20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,15,15,15,15,15,15,15,15,8,8,8,8,8,8,8,8,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,
	0,0,0,0,0,0,0,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,20,15,15,15,15,15,15,15,15,8,8,8,8,8,
	8,8,8,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,20,20,20,20,20,25,39,40,20,20,20,20,20,22,45,38,20,20,20,20,46,47,
	48,49,15,14,14,13,50,51,52,53,8,8,8,7,54,55,29,56,2,2,2,2,57,57,26,58,2,2,2,2,57,57,26,58,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,
};

u8 pelota[256] =
{
	0,0,0,0,0,0,0,0,0,0,0,0,59,59,59,59,0,0,0,59,59,59,59,59,0,0,59,59,59,59,59,59,0,59,59,59,59,59,59,59,0,59,
	59,59,59,59,59,59,0,59,59,59,59,59,59,59,0,59,59,59,59,59,59,59,0,0,0,0,0,0,0,0,59,59,59,59,0,0,0,0,59,59,59,
	59,59,0,0,0,59,59,59,59,59,59,0,0,59,59,59,59,59,59,59,0,59,59,59,59,59,59,59,0,59,59,59,59,59,59,59,0,59,59,
	59,59,59,59,59,0,0,59,59,59,59,59,59,59,0,59,59,59,59,59,59,59,0,59,59,59,59,59,59,59,0,59,59,59,59,59,
	59,59,0,0,59,59,59,59,59,59,0,0,0,59,59,59,59,59,0,0,0,0,59,59,59,59,0,0,0,0,0,0,0,0,59,59,59,59,59,59,
	59,0,59,59,59,59,59,59,59,0,59,59,59,59,59,59,59,0,59,59,59,59,59,59,59,0,59,59,59,59,59,59,0,0,59,59,
	59,59,59,0,0,0,59,59,59,59,0,0,0,0,0,0,0,0,0,0,0,0,
};



u8 erronboHandia[1024] = 
{
	0,0,0,0,0,0,2,2,0,0,0,0,0,2,2,2,0,0,0,0,2,2,2,2,0,0,0,2,2,2,2,2,0,0,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,	

	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,	

	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,	
 
	2,2,0,0,0,0,0,0,2,2,2,0,0,0,0,0,2,2,2,2,0,0,0,0,2,2,2,2,2,0,0,0,2,2,2,2,2,2,0,0,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,	

	2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,

	0,0,0,0,0,0,1,1,0,0,0,0,0,1,1,1,0,0,0,0,1,1,1,1,0,0,0,1,1,1,1,1,0,0,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,	

	1,1,0,0,0,0,0,0,1,1,1,0,0,0,0,0,1,1,1,1,0,0,0,0,1,1,1,1,1,0,0,0,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,	

	2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,

	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,

	2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,0,0,2,2,2,2,2,2,0,0,0,2,2,2,2,2,0,0,0,0,2,2,2,2,0,0,0,0,0,2,2,2,0,0,0,0,0,0,2,2,	

	2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,0,0,2,2,2,2,2,0,0,0,2,2,2,2,0,0,0,0,2,2,2,0,0,0,0,0,2,2,0,0,0,0,0,0,	

	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,

	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,0,0,0,1,1,1,1,1,0,0,0,0,1,1,1,1,0,0,0,0,0,1,1,1,0,0,0,0,0,0,1,1,	

	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,	

	3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,	

	1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,0,0,1,1,1,1,1,0,0,0,1,1,1,1,0,0,0,0,1,1,1,0,0,0,0,0,1,1,0,0,0,0,0,0,	
};

/* Irudikatutako Spriteak memorian kargatzen ditu. SPRITE bat baino gehiago erakusteko
for bana egin behar da.*/

void SpriteakMemorianGorde(){ 
	
int i;
	//16*16ko spriteentzako
	for(i = 0; i < 16 * 16 / 2; i++) 
	{	
		gfxpelota[i] = pelota[i*2] | (pelota[(i*2)+1]<<8);				
	}
	//32*32ko spriteentzako
	for(i = 0; i < 32 * 32 / 2; i++) 
	{	
		//gfxerronboHandia[i] = erronboHandia[i*2] | (erronboHandia[(i*2)+1]<<8);		
		gfxpala[i] = pala[i*2] | (pala[(i*2)+1]<<8);			
	}
}

/* Funtzio honek erronbo bat irudikatzen du pantailako x,y posizioan. Pantailan ateratzea nahi den erronbo 
   bakoitzari indize desberdin bat esleitu behar zaio, 0 eta 126 balioen arteko indizea izan daiteke */

void ErakutsiPelota(int indizea, int x, int y)
{ 
 
oamSet(&oamMain, // main graphics engine context
		indizea,           // oam index (0 to 127)  
		x, y,   // x and y pixel location of the sprite
		0,                    // priority, lower renders last (on top)
		0,					  // this is the palette index if multiple palettes or the alpha value if bmp sprite	
		SpriteSize_16x16,     
		SpriteColorFormat_256Color, 
		gfxpelota,//+16*16/2,                  // pointer to the loaded graphics
		-1,                  // sprite rotation data  
		false,               // double the size when rotating?
		false,			// hide the sprite?
		false, false, // vflip, hflip
		false	// apply mosaic
		); 
	  
oamUpdate(&oamMain);  
}

/* Funtzio honek erronbo baten indizea pasata pantailatik ezabatzen du */
void EzabatuPelota(int indizea, int x, int y)
{

oamSet(&oamMain, // main graphics engine context
		indizea,           // oam index (0 to 127)  
		x, y,   // x and y pixel location of the sprite
		0,                    // priority, lower renders last (on top)
		0,					  // this is the palette index if multiple palettes or the alpha value if bmp sprite	
		SpriteSize_16x16,     
		SpriteColorFormat_256Color, 
		gfxpelota,//+16*16/2,                  // pointer to the loaded graphics
		-1,                  // sprite rotation data  
		false,               // double the size when rotating?
		true,			// hide the sprite?
		false, false, // vflip, hflip
		false	// apply mosaic
		); 
oamUpdate(&oamMain); 

}

void ErakutsiErronboHandia(int indizea, int x, int y)
{ 
 
oamSet(&oamMain, // main graphics engine context
		indizea,           // oam index (0 to 127)  
		x, y,   // x and y pixel location of the sprite
		0,                    // priority, lower renders last (on top)
		0,					  // this is the palette index if multiple palettes or the alpha value if bmp sprite	
		SpriteSize_32x32,     
		SpriteColorFormat_256Color, 
		gfxerronboHandia,//+16*16/2,                  // pointer to the loaded graphics
		-1,                  // sprite rotation data  
		false,               // double the size when rotating?
		false,			// hide the sprite?
		false, false, // vflip, hflip
		false	// apply mosaic
		); 

	  
oamUpdate(&oamMain);  
}

void EzabatuErronboHandia(int indizea, int x, int y)
{

oamSet(&oamMain, // main graphics engine context
		indizea,           // oam index (0 to 127)  
		x, y,   // x and y pixel location of the sprite
		0,                    // priority, lower renders last (on top)
		0,					  // this is the palette index if multiple palettes or the alpha value if bmp sprite	
		SpriteSize_32x32,     
		SpriteColorFormat_256Color, 
		gfxerronboHandia,//+16*16/2,                  // pointer to the loaded graphics
		-1,                  // sprite rotation data  
		false,               // double the size when rotating?
		true,			// hide the sprite?
		false, false, // vflip, hflip
		false	// apply mosaic
		); 
oamUpdate(&oamMain); 

}

//PALA:
void ErakutsiPala(int indizea, int x, int y)
{ 
 
oamSet(&oamMain, // main graphics engine context
		indizea,           // oam index (0 to 127)  
		x, y,   // x and y pixel location of the sprite
		0,                    // priority, lower renders last (on top)
		0,					  // this is the palette index if multiple palettes or the alpha value if bmp sprite	
		SpriteSize_32x32,     
		SpriteColorFormat_256Color, 
		gfxpala,//+16*16/2,                  // pointer to the loaded graphics
		-1,                  // sprite rotation data  
		false,               // double the size when rotating?
		false,			// hide the sprite?
		false, false, // vflip, hflip
		false	// apply mosaic
		); 

	  
oamUpdate(&oamMain);  
}

void EzabatuPala(int indizea, int x, int y)
{

oamSet(&oamMain, // main graphics engine context
		indizea,           // oam index (0 to 127)  
		x, y,   // x and y pixel location of the sprite
		0,                    // priority, lower renders last (on top)
		0,					  // this is the palette index if multiple palettes or the alpha value if bmp sprite	
		SpriteSize_32x32,     
		SpriteColorFormat_256Color, 
		gfxpala,//+16*16/2,                  // pointer to the loaded graphics
		-1,                  // sprite rotation data  
		false,               // double the size when rotating?
		true,			// hide the sprite?
		false, false, // vflip, hflip
		false	// apply mosaic
		); 
oamUpdate(&oamMain); 

}



