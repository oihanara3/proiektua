#include <nds.h>
#include <stdio.h>
#include "definizioak.h"
#include "periferikoak.h"
#include "fondoak.h"
#include "spriteak.h"
#include "pelotamug.h"
#include "kajak.h"


int kajak[3][8] = { {1,2,3,4,5,6,7,8},{9,10,11,12,13,14,15,16},{17,18,19,20,21,22,23,24} };
//Hasieran posizio gutziak hartuta, -1 badago esan nahi du hor kutxa ez dela egon behar.

//no funziona
void reset()
{
	
	kajak[0][0]=1;
	kajak[0][1]=2;
	kajak[0][2]=3;
	kajak[0][3]=4;
	kajak[0][4]=5;
	kajak[0][5]=6;
	kajak[0][6]=7;
	kajak[0][7]=8;

	kajak[1][0]=9;
	kajak[1][1]=10;
	kajak[1][2]=11;
	kajak[1][3]=12;
	kajak[1][4]=13;
	kajak[1][5]=14;
	kajak[1][6]=15;
	kajak[1][7]=16;

	kajak[2][0]=17;
	kajak[2][1]=18;
	kajak[2][2]=19;
	kajak[2][3]=20;
	kajak[2][4]=21;
	kajak[2][5]=22;
	kajak[2][6]=23;
	kajak[2][7]=24;	
			
}



void setLevelOne()
{
	int i;
	int j;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(j%2==0)
			{
				kajak[i][j] = -1;
			}
	
}

void setLevelTwo()
{
	int i;
	int j;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(j%2!=0)
			{
				kajak[i][j] = -1;
			}
	
}

void setLevelThree()
{
	int i;
	int j;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(j<2 || j>5)
			{
				kajak[i][j] = -1;
			}
	
}

int paintLevel(int kajaKop)
{
	int i;
	int j;
	kajaKop = 0;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(kajak[i][j]!=-1)
			{
				ErakutsiKaja(kajak[i][j],j*32,i*32);
				kajaKop++;
			}
	return kajaKop;
}

void kutxaKendu(int indizea,int x,int y)
{
	EzabatuKaja(indizea,x*32,y*32);
}

void kutxaGuztiakKendu()
{
	int i;
	int j;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			kutxaKendu(kajak[i][j],j,i);
}

void paintReset()
{
	int i;
	int j;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(kajak[i][j] != -1)
			{
				kutxaKendu(kajak[i][j],j,i);
			}
}

void setLevel(int levelCount)
{
	switch(levelCount) {
		case 1: setLevelOne();
		break;
		case 2: setLevelTwo();
		break;
		case 3: setLevelThree();
		break;
		default: ;
	}
}




