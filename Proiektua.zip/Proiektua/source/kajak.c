#include <nds.h>
#include <stdio.h>
#include "definizioak.h"
#include "periferikoak.h"
#include "fondoak.h"
#include "spriteak.h"
#include "pelotamug.h"
#include "kajak.h"


int kajak[3][8] = { {1,2,3,4,5,6,7,8},{9,10,11,12,13,14,15,16},{17,18,19,20,21,22,23,24} };
//Hasieran posizio gutziak hartuta, -1 badago esan nahi du hor kutxa ez dela egon behar.


void setLevelOne()
{
	int i;
	int j;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(j%2==0)
			{
				kajak[i][j] = -1;
			}
}

void paintLevel()
{
	int i;
	int j;
	for(i=0; i<3; i++)
		for(j=0; j<8; j++)
			if(kajak[i][j]!=-1)
			{
				ErakutsiKaja(kajak[i][j],j*32,i*32);
			}
}



void kutxaKendu(int indizea,int x,int y){
	EzabatuKaja(indizea,x*32,y*32);
}
